# Date-me-
Como pedir a gata em namoro, estilo programador.
Obs:sem ela dizer não 😈😈

Preview : "https://datemew.netlify.app"
